// EdgeDiscovery.java
package comfaas;

import comfaas.Logger.LogLevel;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketTimeoutException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * A simple background thread that runs only on the Cloud server.
 * It discovers or tracks the IP addresses of Edge servers
 * and writes them into <rootDir>/server/Output/edge_servers.txt every 5
 * seconds.
 */
public class EdgeDiscovery implements Runnable {

    private static final Logger logger = new Logger(Main.getLogFile());

    // The file in which discovered edges are stored
    private final Path outputFilePath;

    public EdgeDiscovery() {
        // We'll place the file in server/Output
        this.outputFilePath = Main.rootDir
                .resolve("server")
                .resolve("Output")
                .resolve("edge_servers.txt");
    }

    @Override
    public void run() {
        logger.logEvent(LogLevel.INFO, "EdgeDiscovery", "run",
                "EdgeDiscovery thread started. Output file: " + outputFilePath, 0, -1);

        // Keep going until the server shuts down
        while (!Server.isShuttingDown()) {
            try {
                List<String> discoveredEdges = discoverEdges();
                writeEdgesToFile(discoveredEdges);

                // Sleep 5 seconds
                Thread.sleep(5000);

            } catch (InterruptedException e) {
                // If interrupted, probably shutting down
                logger.logEvent(LogLevel.WARNING, "EdgeDiscovery", "run",
                        "EdgeDiscovery thread interrupted.", 0, -1);
                Thread.currentThread().interrupt();
                break;
            } catch (IOException e) {
                logger.logEvent(LogLevel.ERROR, "EdgeDiscovery", "run",
                        "Error writing discovered edges: " + e.getMessage(), 0, -1);
            }
        }

        logger.logEvent(LogLevel.INFO, "EdgeDiscovery", "run",
                "EdgeDiscovery thread exiting.", 0, -1);
    }

    /**
     * Real network discovery: sends a discovery message over multicast and listens
     * for responses.
     */
    private List<String> discoverEdges() {
        List<String> discoveredIPs = new ArrayList<>();
        try (MulticastSocket multicastSocket = new MulticastSocket(8888)) {
            InetAddress group = InetAddress.getByName("230.0.0.0");
            multicastSocket.joinGroup(group);
            // Send discovery message
            byte[] msg = "DISCOVER_EDGE".getBytes();
            DatagramPacket packet = new DatagramPacket(msg, msg.length, group, 8888);
            multicastSocket.send(packet);
            // Set timeout for responses
            multicastSocket.setSoTimeout(2000);
            while (true) {
                try {
                    byte[] buffer = new byte[256];
                    DatagramPacket response = new DatagramPacket(buffer, buffer.length);
                    multicastSocket.receive(response);

                    String respMsg = new String(response.getData(), 0, response.getLength()).trim();
                    if (respMsg.startsWith("EDGE_RESPONSE:")) {
                        // e.g. "EDGE_RESPONSE:12355"
                        // The IP is the same (192.168.179.40), but now we can store
                        // a combination of IP + edgeId
                        String edgeId = respMsg.split(":")[1];
                        String ip = response.getAddress().getHostAddress();

                        // Use a composite key like ip + ":" + edgeId
                        String uniqueKey = ip + ":" + edgeId;
                        if (!discoveredIPs.contains(uniqueKey)) {
                            discoveredIPs.add(uniqueKey);
                        }
                    }

                    // Old way:

                    // String respMsg = new String(response.getData(), 0,
                    // response.getLength()).trim();
                    // if ("EDGE_RESPONSE".equals(respMsg)) {
                    // String ip = response.getAddress().getHostAddress();
                    // if (!discoveredIPs.contains(ip)) {
                    // discoveredIPs.add(ip);
                    // }
                    // }
                } catch (SocketTimeoutException e) {
                    break;
                }
            }
            multicastSocket.leaveGroup(group);
        } catch (IOException e) {
            logger.logEvent(LogLevel.ERROR, "EdgeDiscovery", "discoverEdges",
                    "Error discovering edges: " + e.getMessage(), 0, -1);
        }
        logger.logEvent(LogLevel.INFO, "EdgeDiscovery", "discoverEdges",
                "Discovered " + discoveredIPs.size() + " Edge server(s).", 0, -1);
        return discoveredIPs;
    }

    private void writeEdgesToFile(List<String> edgeIPs) throws IOException {
        File outFile = outputFilePath.toFile();
        // Optionally create the parent dir if missing
        outFile.getParentFile().mkdirs();

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outFile, false))) {
            for (String ip : edgeIPs) {
                writer.write(ip);
                writer.newLine();
            }
        }
        logger.logEvent(LogLevel.SUCCESS, "EdgeDiscovery", "writeEdgesToFile",
                "Wrote " + edgeIPs.size() + " Edge IP(s) to " + outFile.getAbsolutePath(), 0, -1);
    }
}
