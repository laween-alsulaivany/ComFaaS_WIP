// EdgeResponder.java
package comfaas;

import comfaas.Logger.LogLevel;
import java.io.IOException;
import java.net.*;

public class EdgeResponder implements Runnable {

    private static final Logger logger = new Logger(Main.getLogFile());
    private volatile boolean running = true;
    String edgeId = "EDGE_RESPONSE:" + Main.serverPort; // or some random ID

    @Override
    public void run() {
        logger.logEvent(LogLevel.INFO, "EdgeResponder", "run",
                "Starting EdgeResponder on 230.0.0.0:8888", 0, -1);

        try (MulticastSocket socket = new MulticastSocket(8888)) {
            InetAddress group = InetAddress.getByName("230.0.0.0");
            socket.joinGroup(group);
            // Listen for discovery messages up to 2s each loop
            socket.setSoTimeout(2000);

            while (running && !Server.isShuttingDown()) {
                try {
                    byte[] buffer = new byte[256];
                    DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                    socket.receive(packet); // blocks up to 2s

                    String message = new String(packet.getData(), 0, packet.getLength()).trim();
                    if ("DISCOVER_EDGE".equals(message)) {
                        logger.logEvent(LogLevel.INFO, "EdgeResponder", "run",
                                "Received DISCOVER_EDGE from " + packet.getAddress(), 0, -1);
                        // Send "EDGE_RESPONSE" BACK TO THE MULTICAST GROUP:
                        byte[] respData = edgeId.getBytes();
                        DatagramPacket respPacket = new DatagramPacket(respData, respData.length, group, 8888);
                        socket.send(respPacket);

                        // Old way:
                        // byte[] respData = "EDGE_RESPONSE".getBytes();
                        // DatagramPacket respPacket = new DatagramPacket(
                        // respData,
                        // respData.length,
                        // group, // same group
                        // 8888 // same port
                        // );
                        // socket.send(respPacket);

                        logger.logEvent(LogLevel.INFO, "EdgeResponder", "run",
                                "Sent EDGE_RESPONSE to group 230.0.0.0:8888", 0, -1);
                    }
                } catch (SocketTimeoutException e) {
                    // Timeout, loop again
                }
            }
            socket.leaveGroup(group);
        } catch (IOException e) {
            logger.logEvent(LogLevel.ERROR, "EdgeResponder", "run",
                    "IOException in EdgeResponder: " + e.getMessage(), 0, -1);
        }

        logger.logEvent(LogLevel.INFO, "EdgeResponder", "run",
                "EdgeResponder thread exiting.", 0, -1);
    }

    public void stopResponder() {
        running = false;
    }
}
