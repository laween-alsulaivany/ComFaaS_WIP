import time

def main():
    # Wait for 3 seconds
    print("Waiting for 3 seconds...")
    time.sleep(3)  # Sleep for 3 seconds
    
    # Print the message
    print("All good to go!")

if __name__ == "__main__":
    main()
