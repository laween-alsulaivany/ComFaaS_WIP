#runserver.sh

java -jar ../ComFaaS.jar server server -p 12353
